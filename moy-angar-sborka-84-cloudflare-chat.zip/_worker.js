// «Мой ангар — WoT Blitz» — серверная часть для Cloudflare Pages (режим _worker.js).
// Делает то же, что папка api/ на Vercel: /api/yt (видео, музыка, превью, прокси BlitzKit), /api/geo (город по IP), /api/news (RSS).
// Всё остальное — обычные файлы сайта; к ним добавляются заголовки безопасности (как в vercel.json).

const HDR = [{"source": "/fonts/(.*)", "headers": [{"key": "Access-Control-Allow-Origin", "value": "*"}, {"key": "Cache-Control", "value": "public, max-age=31536000, immutable"}]}, {"source": "/maps/(.*)", "headers": [{"key": "Cache-Control", "value": "public, max-age=604800"}]}, {"source": "/vendor/(.*)", "headers": [{"key": "Cache-Control", "value": "public, max-age=31536000, immutable"}, {"key": "Access-Control-Allow-Origin", "value": "*"}]}, {"source": "/(.*)", "headers": [{"key": "Content-Security-Policy", "value": "default-src 'self'; script-src 'self' 'wasm-unsafe-eval' 'unsafe-hashes' 'sha256-4D6WvydUlUAYOaST0Tg3Ja9DBjFcXezOuCI2z93SDEo=' 'sha256-AgBJgD4kxwO5Ak/Oewuv5KjVSUO2R4YNZqog9rTtRQo=' 'sha256-DBQjhtBUOlmW6by5cqOBp0lXSWxO60r6C5NzMwXtmq0=' 'sha256-LAvm9cMJEEKfb+1Yev2QD2afgPOmDSM6Gwn5JUm8Ta4=' 'sha256-ZHUeZzULIrcBcrE34MibXKKrb8ERheiV142TbDPB+lc=' 'sha256-apPCxmZal3Qujkiak6bse/jdO/zCGMOnSNi/iTP4YFA=' 'sha256-sF7YeEX1l2HandffEo9a/L8WN+mxIRv4up1r9XeP20M=' 'sha256-juwncnJHMyGOq87/zuAs1GsQrETYfLnGs7Zf4P5xA/E=' 'sha256-3xO8NGQhtGUtymJkmF11qMsdbSEFtXPlNqT53szkK74=' 'sha256-J1BsLXuoKeWlZAMOTTuxN6oQCWV4UqHkbxgkt1eObHc=' 'sha256-Pwhgg4UEJIkbPTIazWL8JrDDqkRWXTSuTKqs4K/l2c4=' 'sha256-HTmLl5SbQTWE5O0vVsM3Xfn0Kg8aD1O/dlISaOK598Q=' 'sha256-3ajZb2th+F7NI2zl0qarYIhkLInAlc/W/t7vDht3HDY=' 'sha256-BKV+rjoyzXxtrIIXV2U/BG7zLoXY9LyCqlMJTOISN9w=' 'sha256-zhxvaL9KrNhmSLhAHETqfyPdDCPU1pcohS0YC5tbqU0=' 'sha256-xZcSowpKiirytjEaoJCMO/pB8s1/r2+yT7Yf1BkOCYs=' 'sha256-BZEeqtJT8ANQsJud1WwymnyVBpAN31WybPwHsjIlT9A=' 'sha256-9f8ZK5epjuMsYtXFjPqrgJI0L4QOAUYmJdHtT+RSH/c=' 'sha256-pwQduWxX3Cm7lLbQmAos7n73RLP4QrsCDFejmsBdZ78=' 'sha256-2v15HA+jcUVSuZj1qG3oTd5Ic+VBbl+6+8wh+TEIxBI=' 'sha256-pCskzJ4cthVFsKCBztl/QsVrmsL54PFXHWiThuLAfhI=' 'sha256-mhmtgT9B4GJPBnTyqeI9IEDXieHblGO6Z42YKX9qcqc=' 'sha256-+US6Y4IX6YivGYoEvIpB6A9EPp83+RjepWmYcJnF6hY='; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' data: blob: https:; font-src 'self' data: https://cdn.jsdelivr.net https://fonts.gstatic.com; connect-src 'self' https: data: blob:; frame-src https:; worker-src 'self' blob:; manifest-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'"}, {"key": "X-Content-Type-Options", "value": "nosniff"}, {"key": "Referrer-Policy", "value": "strict-origin-when-cross-origin"}, {"key": "Permissions-Policy", "value": "microphone=(self), geolocation=(self), camera=(), payment=(), usb=()"}, {"key": "X-Frame-Options", "value": "SAMEORIGIN"}]}];
const HDR_RX = HDR.map(r => [new RegExp('^' + r.source.replace(/\(\.\*\)/g, '(.*)') + '$'), r.headers]);

/* ---------- защита: лимит запросов с одного IP, только со своего сайта ---------- */
const BUCKETS = new Map();
const WINDOW = 60 * 1000;
const ipOf = req => req.headers.get('cf-connecting-ip') || (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || '?';
const hostOf = v => { try { return new URL(String(v)).host.toLowerCase(); } catch (e) { return null; } };
function sameSite(req, url) {
  const own = url.host.toLowerCase();
  const local = x => /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(x);
  for (const k of ['origin', 'referer']) {
    const v = req.headers.get(k);
    if (!v || v === 'null') continue;
    const o = hostOf(v);
    if (!o) return false;
    if (o !== own && !local(o)) return false;
  }
  return true;
}
function limit(req, kind, max) {
  const now = Date.now(), key = kind + '|' + ipOf(req);
  let b = BUCKETS.get(key);
  if (!b || now - b.t > WINDOW) { b = { n: 0, t: now }; BUCKETS.set(key, b); }
  b.n++;
  if (BUCKETS.size > 5000) {
    for (const [k, v] of BUCKETS) if (now - v.t > WINDOW) BUCKETS.delete(k);
    if (BUCKETS.size > 5000) BUCKETS.clear();
  }
  return b.n <= max ? 0 : Math.ceil((b.t + WINDOW - now) / 1000);
}
const BASE = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Vary': 'Origin' };
function out(body, status, h) { return new Response(body, { status: status || 200, headers: Object.assign({}, BASE, h || {}) }); }
const json = (o, status, h) => out(JSON.stringify(o), status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, h || {}));
// null — можно продолжать; иначе готовый ответ
function guard(req, url, kind, max) {
  const m = req.method.toUpperCase();
  if (m === 'OPTIONS') return out(null, 204);
  if (m !== 'GET' && m !== 'HEAD') return out(null, 405, { Allow: 'GET, HEAD' });
  if (!sameSite(req, url)) return out(null, 403);
  const wait = limit(req, kind, max);
  if (wait) return out('{"items":[],"error":"busy"}', 429, { 'Retry-After': String(wait), 'Content-Type': 'application/json; charset=utf-8' });
  return null;
}
// читает ответ, но не больше max байт
async function readCapped(r, max) {
  const len = +r.headers.get('content-length') || 0;
  if (len > max) throw new Error('too-big');
  const rd = r.body.getReader(), parts = [];
  let n = 0;
  for (;;) {
    const { done, value } = await rd.read();
    if (done) break;
    n += value.length;
    if (n > max) { try { rd.cancel(); } catch (e) {} throw new Error('too-big'); }
    parts.push(value);
  }
  const all = new Uint8Array(n);
  let o = 0;
  for (const p of parts) { all.set(p, o); o += p.length; }
  return all;
}
async function timed(url, opt, ms) {
  const ac = new AbortController(), tm = setTimeout(() => ac.abort(), ms);
  try { return await fetch(url, Object.assign({ signal: ac.signal }, opt)); } finally { clearTimeout(tm); }
}

/* ---------- /api/geo ---------- */
function geo(req, url) {
  const g = guard(req, url, 'geo', 20); if (g) return g;
  const cf = req.cf || {};
  const s = v => v == null || v === '' ? null : String(v).slice(0, 80);
  const num = v => (v != null && v !== '' && !isNaN(+v)) ? +v : null;
  return json({ city: s(cf.city), region: s(cf.regionCode || cf.region), country: s(cf.country), lat: num(cf.latitude), lon: num(cf.longitude), tz: s(cf.timezone) }, 200, { 'Cache-Control': 'private, no-store' });
}

/* ---------- /api/news ---------- */
async function news(req, url) {
  const g = guard(req, url, 'news', 30); if (g) return g;
  const raw = String(url.searchParams.get('url') || '');
  if (raw.length > 800) return out('too long', 414);
  let u;
  try { u = new URL(raw); } catch (e) { return out('bad url', 400); }
  if (u.protocol !== 'https:' || u.hostname !== 'news.google.com' || u.port || u.username || u.password || !/^\/rss(\/|$)/.test(u.pathname)) return out('forbidden', 403);
  try {
    const r = await timed(u.href, { redirect: 'manual', headers: { 'User-Agent': 'Mozilla/5.0 (compatible; MoyAngar/1.0)', 'Accept': 'application/rss+xml,text/xml;q=0.9,*/*;q=0.8' } }, 8000);
    if (!r.ok) return out('', r.status >= 400 && r.status < 600 ? r.status : 502);
    const body = await readCapped(r, 2 * 1024 * 1024);
    return out(body, 200, { 'Content-Type': 'application/rss+xml; charset=utf-8', 'Content-Security-Policy': "default-src 'none'; sandbox", 'Cache-Control': 'public, max-age=600, s-maxage=1800' });
  } catch (e) { return out('', 502); }
}

/* ---------- /api/yt ---------- */
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36';
const COOKIE = 'CONSENT=YES+cb.20210328-17-p0.en+FX+700; SOCS=CAI';
const day = () => new Date().toISOString().slice(0, 10).replace(/-/g, '');
const ctxWeb = () => ({ client: { clientName: 'WEB', clientVersion: '2.' + day() + '.00.00', hl: 'ru', gl: 'RU' } });
const ctxMusic = () => ({ client: { clientName: 'WEB_REMIX', clientVersion: '1.' + day() + '.01.00', hl: 'ru', gl: 'RU' } });
const P_VIDEOS = 'EgIQAQ%3D%3D';
const P_SONGS = 'EgWKAQIIAWoMEA4QChADEAQQCRAF';
const secs = t => String(t || '').split(':').reduce((a, x) => a * 60 + (+x || 0), 0);
const txt = o => !o ? '' : o.simpleText != null ? String(o.simpleText) : (o.runs || []).map(r => r.text).join('');

async function post(u, body, origin, ms = 9000) {
  const r = await timed(u, { method: 'POST', headers: { 'Content-Type': 'application/json', 'User-Agent': UA, Origin: origin, Referer: origin + '/', Cookie: COOKIE, 'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.7' }, body: JSON.stringify(body) }, ms);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return await r.json();
}
function nextToken(o) {
  let tok = null;
  (function walk(x) {
    if (tok || !x || typeof x !== 'object') return;
    if (x.continuationCommand && x.continuationCommand.token) { tok = x.continuationCommand.token; return; }
    if (x.nextContinuationData && x.nextContinuationData.continuation) { tok = x.nextContinuationData.continuation; return; }
    for (const k in x) walk(x[k]);
  })(o);
  return tok;
}
function videosFrom(o) {
  const res = [];
  (function walk(x) {
    if (!x || typeof x !== 'object') return;
    const v = x.videoRenderer;
    if (v && v.videoId) {
      const live = (v.badges || []).some(b => /LIVE/.test(JSON.stringify(b))) || !v.lengthText;
      res.push({ id: v.videoId, title: txt(v.title), a: txt(v.ownerText || v.longBylineText), d: secs(txt(v.lengthText)), th: 'https://i.ytimg.com/vi/' + v.videoId + '/mqdefault.jpg', live });
      return;
    }
    for (const k in x) walk(x[k]);
  })(o);
  return res;
}
async function searchVideos(q, c) {
  const body = c ? { context: ctxWeb(), continuation: c } : { context: ctxWeb(), query: q, params: P_VIDEOS };
  const j = await post('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', body, 'https://www.youtube.com');
  return { items: videosFrom(j), next: nextToken(c ? j.onResponseReceivedCommands || j : j.contents || j), src: 'innertube' };
}
async function scrapeVideos(q) {
  const r = await timed('https://www.youtube.com/results?hl=ru&gl=RU&sp=EgIQAQ%253D%253D&search_query=' + encodeURIComponent(q), { headers: { 'User-Agent': UA, Cookie: COOKIE, 'Accept-Language': 'ru-RU,ru;q=0.9' } }, 9000);
  const html = await r.text();
  const m = html.match(/var ytInitialData = (\{[\s\S]*?\});<\/script>/) || html.match(/ytInitialData"\]\s*=\s*(\{[\s\S]*?\});/);
  if (!m) throw new Error('no-data');
  return { items: videosFrom(JSON.parse(m[1])), next: null, src: 'scrape' };
}
const PIPED = ['https://pipedapi.kavin.rocks', 'https://pipedapi.adminforge.de', 'https://api.piped.private.coffee'];
async function pipedVideos(q) {
  for (const b of PIPED) {
    try {
      const r = await timed(b + '/search?filter=videos&q=' + encodeURIComponent(q), { redirect: 'manual', headers: { 'User-Agent': UA } }, 6000);
      if (!r.ok) continue;
      const j = JSON.parse(new TextDecoder().decode(await readCapped(r, 1024 * 1024)));
      const items = ((j && j.items) || []).map(x => ({ id: (String(x.url || '').match(/v=([\w-]{11})/) || [])[1], title: String(x.title || ''), a: String(x.uploaderName || ''), d: +x.duration || 0, th: x.thumbnail || '', live: x.duration === -1 })).filter(x => x.id);
      if (items.length) return { items, next: null, src: 'piped' };
    } catch (e) {}
  }
  throw new Error('piped');
}
function songsFrom(o) {
  const res = [];
  (function walk(x) {
    if (!x || typeof x !== 'object') return;
    const s = x.musicResponsiveListItemRenderer;
    if (s) {
      const id = (s.playlistItemData && s.playlistItemData.videoId) ||
        ((((((s.overlay || {}).musicItemThumbnailOverlayRenderer || {}).content || {}).musicPlayButtonRenderer || {}).playNavigationEndpoint || {}).watchEndpoint || {}).videoId;
      if (id) {
        const cols = (s.flexColumns || []).map(c => (c.musicResponsiveListItemFlexColumnRenderer || {}).text || {});
        const title = txt(cols[0]);
        const parts = (cols[1] && cols[1].runs || []).map(r => r.text).join('').split(' • ').map(t => t.trim()).filter(Boolean);
        const dur = parts.find(p => /^\d{1,2}:\d{2}(:\d{2})?$/.test(p));
        const ths = ((((s.thumbnail || {}).musicThumbnailRenderer || {}).thumbnail || {}).thumbnails) || [];
        const th = ths.length ? ths[Math.min(1, ths.length - 1)].url : 'https://i.ytimg.com/vi/' + id + '/mqdefault.jpg';
        res.push({ id, title, a: parts.filter(p => p !== dur && !/^(Песня|Song|Видео|Video|Трек)$/i.test(p))[0] || '', d: secs(dur), th });
      }
      return;
    }
    for (const k in x) walk(x[k]);
  })(o);
  return res;
}
async function searchSongs(q, c) {
  const base = 'https://music.youtube.com/youtubei/v1/search?prettyPrint=false';
  const u = c ? base + '&ctoken=' + encodeURIComponent(c) + '&continuation=' + encodeURIComponent(c) + '&type=next' : base;
  const body = c ? { context: ctxMusic() } : { context: ctxMusic(), query: q, params: P_SONGS };
  const j = await post(u, body, 'https://music.youtube.com');
  return { items: songsFrom(j), next: nextToken(c ? j.continuationContents || j : j.contents || j), src: 'ytmusic' };
}
async function embeddable(id) {
  try {
    const r = await timed('https://www.youtube.com/oembed?format=json&url=https://www.youtube.com/watch?v=' + id, { headers: { 'User-Agent': UA } }, 2500);
    return r.status !== 401 && r.status !== 403 && r.status !== 404;
  } catch (e) { return true; }
}
async function onlyEmbeddable(items) {
  const head = items.slice(0, 20), ok = await Promise.all(head.map(x => embeddable(x.id)));
  return head.filter((x, i) => ok[i]).concat(items.slice(20));
}
const safeType = t => {
  t = String(t || '').toLowerCase().split(';')[0].trim();
  if (/^image\/(png|jpe?g|webp|gif|avif|svg\+xml)$/.test(t)) return t;
  if (/^(application\/(json|octet-stream|x-protobuf|protobuf)|model\/gltf-binary|model\/gltf\+json)$/.test(t)) return t;
  return 'application/octet-stream';
};
async function yt(req, url) {
  const Q = k => url.searchParams.get(k);
  const has = k => url.searchParams.has(k);
  const kind = has('px') ? 'px' : has('th') ? 'th' : Q('ping') ? 'ping' : 'yt';
  const g = guard(req, url, kind, { px: 240, th: 300, ping: 30, yt: 120 }[kind]); if (g) return g;
  if (has('px')) {
    const raw = String(Q('px'));
    if (raw.length > 600) return out(null, 414);
    let u; try { u = new URL(raw); } catch (e) { return out(null, 400); }
    if (u.protocol !== 'https:' || u.port || u.username || u.password || !/(^|\.)(blitzkit\.app|blitzstars\.com|gcdn\.co|wgcdn\.co)$/.test(u.hostname)) return out(null, 403);
    try {
      const r = await timed(u.href, { redirect: 'manual', headers: { 'User-Agent': UA } }, 9000);
      if (!r.ok) return out(null, r.status >= 400 && r.status < 600 ? r.status : 502);
      const body = await readCapped(r, 20 * 1024 * 1024);
      return out(body, 200, { 'Content-Type': safeType(r.headers.get('content-type')), 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; sandbox", 'Cache-Control': 'public, max-age=3600, s-maxage=21600' });
    } catch (e) { return out(null, String(e.message) === 'too-big' ? 413 : 502); }
  }
  if (has('th')) {
    const id = String(Q('th')), sz = Q('s') === 'hq' ? 'hq' : 'mq';
    if (!/^[\w-]{11}$/.test(id)) return out(null, 400);
    try {
      const r = await timed(`https://i.ytimg.com/vi/${id}/${sz}default.jpg`, { headers: { 'User-Agent': UA } }, 8000);
      if (!r.ok) return out(null, 404);
      const body = await readCapped(r, 512 * 1024);
      const ct = r.headers.get('content-type') || '';
      return out(body, 200, { 'Content-Type': /^image\/(jpeg|webp|png)/.test(ct) ? ct : 'image/jpeg', 'Cache-Control': 'public, max-age=86400, s-maxage=2592000, immutable' });
    } catch (e) { return out(null, 502); }
  }
  if (Q('ping')) return json({ ok: true, items: [] });
  const music = has('m') && !has('q');
  const q = String((music ? Q('m') : Q('q')) || '').trim().slice(0, 150);
  const c = String(Q('c') || '').slice(0, 2000) || null;
  if (!q && !c) return json({ items: [], error: 'empty' }, 400);
  let res = null; const errs = [];
  const tries = music
    ? [() => searchSongs(q, c), () => c ? Promise.reject(new Error('-')) : searchVideos(q + ' official audio')]
    : [() => searchVideos(q, c), () => c ? Promise.reject(new Error('-')) : scrapeVideos(q), () => c ? Promise.reject(new Error('-')) : pipedVideos(q)];
  for (const f of tries) {
    try { const r = await f(); if (r.items.length) { res = r; break; } } catch (e) { errs.push(String(e.message || e)); }
  }
  if (!res) return json({ items: [], next: null, error: errs.join('; ') || 'empty' }, 502);
  const seen = new Set();
  let items = res.items.filter(x => x.id && !x.live && !seen.has(x.id) && seen.add(x.id));
  items = await onlyEmbeddable(items);
  return json({ items: items.map(({ live, ...x }) => x), next: res.next || null, src: res.src }, 200, { 'Cache-Control': 's-maxage=21600, stale-while-revalidate=86400' });
}


/* ================================================================
   «Мой ангар» — соцсеть: вход через Wargaming, чат, комнаты, личка,
   фильтр, модерация, профили. Хранилище — Cloudflare D1 (привязка DB).
   Создатель и главный модератор — OWNER_NICK.
   ================================================================ */
const OWNER_NICK = 'vlad6660000';
const SOC_APP = '7ead0190d7f81464c4c1e2c0fb18ba7f';                 // ключ приложения Wargaming (подставляется при сборке)
const TLD = { eu: 'eu', na: 'com', asia: 'asia' };
const DAY = 86400000;
const PUB_ROOMS = [
  ['pub:general', 'общий'], ['pub:squad', 'поиск-взвода'], ['pub:tech', 'обсуждение-техники'],
  ['pub:builds', 'сборки-и-советы'], ['pub:new', 'новички-спрашивают'],
  ['lang:ru', 'ru'], ['lang:ua', 'ua'], ['lang:en', 'en'], ['lang:de', 'de'], ['lang:pl', 'pl']
];
const PUB_SET = new Set(PUB_ROOMS.map(r => r[0]));

/* ---------- схема (создаётся сама при первом запросе) ---------- */
let SCHEMA_OK = false;
async function schema(db) {
  if (SCHEMA_OK) return;
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, realm TEXT, nick TEXT, nick_l TEXT, clan_id INTEGER DEFAULT 0, clan_tag TEXT DEFAULT '', avatar TEXT DEFAULT '', status TEXT DEFAULT '', role TEXT DEFAULT 'user', dm_mode TEXT DEFAULT 'all', created INTEGER, last_seen INTEGER, muted_until INTEGER DEFAULT 0, banned INTEGER DEFAULT 0, strikes INTEGER DEFAULT 0, last_strike INTEGER DEFAULT 0)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS users_nick ON users(nick_l)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS sessions(h TEXT PRIMARY KEY, uid INTEGER, created INTEGER, expires INTEGER, wgt TEXT, realm TEXT)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY, kind TEXT, name TEXT, owner INTEGER DEFAULT 0, privacy TEXT DEFAULT 'open', invite TEXT DEFAULT '', created INTEGER, last_ts INTEGER DEFAULT 0)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS rooms_inv ON rooms(invite)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS members(room TEXT, uid INTEGER, role TEXT DEFAULT 'member', last_read INTEGER DEFAULT 0, PRIMARY KEY(room, uid))`),
    db.prepare(`CREATE INDEX IF NOT EXISTS members_uid ON members(uid)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT, uid INTEGER, ts INTEGER, text TEXT, card TEXT DEFAULT '', hidden INTEGER DEFAULT 0, reports INTEGER DEFAULT 0)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS msgs_room ON msgs(room, id)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS msgs_uid ON msgs(uid, id)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS reports(mid INTEGER, uid INTEGER, ts INTEGER, PRIMARY KEY(mid, uid))`),
    db.prepare(`CREATE TABLE IF NOT EXISTS blocks(uid INTEGER, bid INTEGER, PRIMARY KEY(uid, bid))`),
    db.prepare(`CREATE TABLE IF NOT EXISTS modlog(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, actor INTEGER, action TEXT, target INTEGER, info TEXT)`)
  ]);
  SCHEMA_OK = true;
}

/* ---------- утилиты ---------- */
const enc = new TextEncoder();
const b64u = buf => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const rnd = n => { const a = new Uint8Array(n); crypto.getRandomValues(a); return b64u(a); };
const sha = async s => b64u(await crypto.subtle.digest('SHA-256', enc.encode(s)));
const now = () => Date.now();
const sj = (o, st, h) => new Response(JSON.stringify(o), { status: st || 200, headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' }, h || {}) });
const err = (code, st, extra) => sj(Object.assign({ error: code }, extra || {}), st || 400);
function cookieOf(req, name) { const c = req.headers.get('cookie') || ''; const m = c.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)')); return m ? m[1] : null; }
const clean = (s, max) => String(s == null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F​-‏‪-‮⁦-⁩]/g, '').trim().slice(0, max);
const AV_RX = /^a1(-\d{1,2}){5}$/;

/* ---------- лимит запросов (в памяти изолята) ---------- */
const SB = new Map();
function hit(key, max, win) { const t = now(); let b = SB.get(key); if (!b || t - b.t > win) { b = { n: 0, t }; SB.set(key, b); } b.n++; if (SB.size > 20000) SB.clear(); return b.n <= max; }

/* ================= ФИЛЬТР ================= */
const VIS = { a: 'а', b: 'в', c: 'с', e: 'е', h: 'н', k: 'к', m: 'м', o: 'о', p: 'р', t: 'т', x: 'х', y: 'у', '0': 'о', '3': 'з', '4': 'ч', '6': 'б', '9': 'я', '@': 'а', '$': 'с', 'u': 'и', 'i': 'и', 'r': 'г', 'n': 'п' };
const TRL = { a: 'а', b: 'б', c: 'ц', d: 'д', e: 'е', f: 'ф', g: 'г', h: 'х', i: 'и', j: 'й', k: 'к', l: 'л', m: 'м', n: 'н', o: 'о', p: 'п', q: 'к', r: 'р', s: 'с', t: 'т', u: 'у', v: 'в', w: 'в', x: 'х', y: 'й', z: 'з', '0': 'о', '3': 'з', '4': 'ч', '6': 'б', '9': 'я', '@': 'а', '$': 'с' };
const CYR = /[а-яё]/;
function base(s) {
  return s.toLowerCase().replace(/ё/g, 'е').replace(/[іїİ]/g, 'и').replace(/є/g, 'е').replace(/ґ/g, 'г').replace(/ъ/g, 'ь');
}
function mapWord(w, M) { if (M === TRL) w = w.replace(/shch/g, 'щ').replace(/(zh|sh|ch|kh|ts)/g, x => ({ zh: 'ж', sh: 'ш', ch: 'ч', kh: 'х', ts: 'ц' })[x]).replace(/y[aueo]/g, x => ({ ya: 'я', yu: 'ю', ye: 'е', yo: 'е' })[x]).replace(/ja/g, 'я'); let o = ''; for (const ch of w) o += M[ch] != null ? M[ch] : ch; return o; }
const squeeze = s => s.replace(/(.)\1{2,}/g, '$1$1').replace(/([а-яa-z])\1+/g, '$1');
/* варианты текста для проверки: как есть, «визуальная» латиница→кириллица, транслит, склеенные «л о х» и «л.о.х» */
function variants(text) {
  const b = base(text);
  const words = b.split(/\s+/).filter(Boolean);
  const out = new Set();
  const joinSingles = ws => { const r = []; let run = ''; for (const w of ws) { const c = w.replace(/[^a-zа-я0-9@$*]/g, ''); if (c.length === 1) run += c; else { if (run) r.push(run); run = ''; r.push(w); } } if (run) r.push(run); return r; };
  for (const ws of [words, joinSingles(words)]) {
    const plain = ws.map(w => w.replace(/[.\-_~+|/\\,'"`!?:;()\[\]{}<>^]+/g, '')).filter(Boolean);
    const vis = plain.map(w => (CYR.test(w) || /[0-9@$]/.test(w)) ? mapWord(w, VIS) : w);
    const tr = plain.map(w => /^[a-z0-9@$*]+$/.test(w) ? mapWord(w, TRL) : w);
    for (const arr of [plain, vis, tr]) { out.add(' ' + arr.join(' ') + ' '); out.add(' ' + arr.map(squeeze).join(' ') + ' '); }
  }
  // звёздочки: подставляем гласные
  const res = [];
  for (const v of out) {
    if (v.includes('*')) { for (const ch of 'аеиоуяыю') res.push(v.replace(/\*/g, ch)); res.push(v.replace(/\*/g, '')); }
    else res.push(v);
  }
  return res;
}
const W0 = '(?:^|[^а-яa-z])', W1 = '(?:$|[^а-яa-z])';
const RX = (s) => new RegExp(s.replace(/\^/g, W0).replace(/\$/g, W1));
const WHITE = /(страху|рубля|сукн|мандар|хлеба|колеба|потреба|ребят|оскорбл|употребл|скребл|херсон|психуе|пихуй)/;
const RULES = [
  ['mat', 'мат', [
    'ху[йеияюё]', 'пизд', 'п[ие]зж', '^(за|на|по|у|вы|от|до|при|рас|раз|об|пере|недо|съ|въ|подъ|долбо|)еб(а|у|и|л|н|ыв|ет|ут|ан|ло)', 'долбо[её]б',
    '^бл(я|ят|ед|д)', '^с[уy]к(а|и|у|е|ой|ин)$', 'муда[кч]', 'мудил', 'пидор', 'пидар', '^педик', '^пидр', 'гандон', 'гондон', 'залуп', 'шлюх', 'шалав',
    '^дроч', '^манда', 'дерьм', '^говн', '^жоп', 'обоср', 'засран', 'курв', 'fuck', 'shit', 'bitch', 'cunt', 'motherf', 'asshole', 'kurw', 'chuj', 'pierdol', 'jeban', 'scheiss', 'hurensohn', 'fotze', 'wichser', 'arschloch'
  ]],
  ['insult', 'оскорбление', [
    '^лох(|а|и|у|ом|ам|ами|уш[ка])$', '^дебил', '^идиот', '^кретин', '^даун$', '^аутист', '^чмо', '^урод', '^тупица', 'тупорыл', '^дура(к|ч|$)', '^ничтожеств', '^петух$', '^петуш', '^шлак$', '^уебан', '^ушлеп', 'retard', 'nigg', '^faggot', '^fag$', '^whore', '^slut', '^idiot', '^moron'
  ]],
  ['politics', 'политика и война запрещены', [
    'путин', 'зеленск', 'порошенк', 'навальн', 'лукашенк', 'байден', 'трамп', '^сво$', 'спецопераци', '^зсу$', '^всу$', 'рашист', '^рашк', '^раш(а|и|у)$', 'русня', '^русн', 'хохл', '^хохол', 'кацап', 'москал', '^ватник', '^укроп', 'бандер', 'бандерлог', '^орк(и|ов|ам|ами)$', 'донбас', '^днр$', '^лнр$', 'мобилизац', 'оккупант', 'окупант', 'аннекси', 'крымнаш', 'крым наш', 'слава укра', 'героям слава', 'путлер', 'кремл', 'майдан', '^нато$', 'войн[аеуы] (в|на) украин', 'війн', 'русский мир', '^азов$', 'вагнер', '^zov$', '^z$', '^v$', 'putin', 'zelensk', 'ukraine war', 'war in ukraine'
  ]],
  ['drugs', 'наркотики запрещены', [
    'наркот', 'кладмен', 'закладчик', '^меф$', 'мефедрон', 'гашиш', 'марихуан', 'канабис', 'каннабис', 'кокаин', 'героин', 'амфетамин', '^спайс', 'экстази', '^лсд$', 'барыг', 'cocaine', 'heroin', '^weed$', '^meth$', '^mdma$'
  ]],
  ['violence', 'угрозы и призывы к насилию запрещены', [
    '(убью|зарежу|прирежу|застрелю|пристрелю|задушу|урою|закопаю) (тебя|вас|тя|твою|всех)', '(тебя|вас|тя) (убью|зарежу|прирежу|застрелю|пристрелю|найду и)', '^сдохни', '^убей себя', '^убейся', '^выпились', 'теракт', 'взорв(у|ать|ем) (школ|дом|вас)', 'kill yourself', '^kys$'
  ]],
  ['sale', 'продажа и обмен аккаунтов запрещены', [
    '(прода[мюет]|продаю|куплю|покупаю|обменяю|меняю|отдам) .{0,25}(акк|аккаунт|учетк|account|^acc$)', '(акк|аккаунт|учетк)[а-я]* .{0,12}(на продажу|продам|продаю|за \\d|за деньги|дешево)', 'funpay', 'фанпей', 'playerok', 'плеерок', '^g2g$', 'eldorado\\.gg', '(продам|продаю|куплю) (голд|золот)', '(дешев|дешёв)[а-я]* (голд|золот)'
  ]],
  ['phish', 'похоже на мошенничество', [
    'бесплатн[а-я]* (золот|голд|премиум|танк|акк)', '(золот|голд|премиум)[а-я]* бесплатно', 'введи (свой )?(логин|пароль)', '(скинь|дай|напиши) (свой )?(логин|пароль)', 'free (gold|premium|tank)', 'giveaway.{0,20}(login|password)'
  ]]
].map(([k, label, arr]) => [k, label, arr.map(RX)]);
const ALLOW = /(^|\.)(wargaming\.net|wotblitz\.(eu|com|asia)|worldoftanks\.(eu|com|asia)|blitzkit\.app|blitzstars\.com|youtube\.com|youtu\.be|twitch\.tv)$/;
const URLRX = /\b((?:https?:\/\/|www\.)[^\s<>"']+|[a-z0-9-]{2,}(?:\.[a-z0-9-]{2,})*\.(?:ru|com|net|org|io|gg|me|xyz|top|site|online|link|shop|club|info|ua|pl|de|eu|app|dev|tk|cf|ml|ga|gq|su|by|kz|cc|tv|be|ly|to|biz|pro|space|store|fun)\b(?:\/[^\s]*)?)/gi;
const lev = (a, b) => { const m = a.length, n = b.length; if (Math.abs(m - n) > 2) return 3; const d = Array.from({ length: m + 1 }, (_, i) => [i]); for (let j = 1; j <= n; j++) d[0][j] = j; for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[m][n]; };
function checkLinks(text, ownHost) {
  const urls = String(text).match(URLRX) || [];
  for (const u of urls) {
    let h = u.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split(/[\/?#:]/)[0];
    if (!h || h === ownHost || ALLOW.test(h)) continue;
    const core = h.split('.').slice(-2, -1)[0] || h;
    if (/wargam|wotb|blitz|worldoftank|wot-/.test(h) || lev(core, 'wargaming') <= 2 || lev(core, 'wotblitz') <= 2) return ['phish', 'поддельная ссылка Wargaming — похоже на мошенничество'];
    return ['link', 'ссылки разрешены только на Wargaming, YouTube, Twitch, BlitzKit и BlitzStars'];
  }
  return null;
}
function filterText(text, ownHost) {
  if (!text) return null;
  const l = checkLinks(text, ownHost); if (l) return l;
  const vs = variants(text);
  for (const [k, label, rxs] of RULES) {
    for (const v of vs) {
      const v2 = k === 'mat' ? v.replace(WHITE, ' ') : v;
      for (const r of rxs) if (r.test(v2)) return [k, label];
    }
  }
  return null;
}

/* ================= WARGAMING ================= */
async function wgPost(realm, path, params) {
  const u = `https://api.worldoftanks.${TLD[realm]}/wot/${path}/`;
  const body = new URLSearchParams(Object.assign({ application_id: SOC_APP }, params));
  const r = await fetch(u, { method: 'POST', body, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
  return r.json();
}
async function wgb(realm, path, params) {
  const q = new URLSearchParams(Object.assign({ application_id: SOC_APP }, params));
  const r = await fetch(`https://api.wotblitz.${TLD[realm]}/wotb/${path}/?${q}`);
  return r.json();
}

/* ================= СЕССИЯ ================= */
async function me(req, db) {
  const tok = cookieOf(req, 'wbs'); if (!tok || tok.length > 80) return null;
  const h = await sha(tok);
  const s = await db.prepare('SELECT uid, expires FROM sessions WHERE h=?').bind(h).first();
  if (!s || s.expires < now()) return null;
  const u = await db.prepare('SELECT * FROM users WHERE id=?').bind(s.uid).first();
  if (!u) return null;
  if (now() - (u.last_seen || 0) > 60000) await db.prepare('UPDATE users SET last_seen=? WHERE id=?').bind(now(), u.id).run();
  u._h = h; return u;
}
const pubUser = u => u && ({ id: u.id, nick: u.nick, realm: u.realm, clan: u.clan_tag || '', av: u.avatar || '', st: u.status || '', role: u.role, dm: u.dm_mode, created: u.created, seen: u.last_seen, muted: u.muted_until > now() ? u.muted_until : 0, banned: !!u.banned });
const isMod = u => u && (u.role === 'owner' || u.role === 'mod');

/* доступ к комнате: чтение / запись */
async function access(db, u, room) {
  if (PUB_SET.has(room)) return { read: true, write: !!u };
  if (!u) return { read: false, write: false };
  if (room.startsWith('clan:')) { const ok = u.clan_id && room === 'clan:' + u.clan_id; return { read: ok || isMod(u), write: ok }; }
  if (room.startsWith('dm:')) { const [, a, b] = room.split(':'); const ok = String(u.id) === a || String(u.id) === b; return { read: ok, write: ok }; }
  if (room.startsWith('g:')) {
    const r = await db.prepare('SELECT privacy FROM rooms WHERE id=?').bind(room).first(); if (!r) return { read: false, write: false };
    const m = await db.prepare('SELECT role FROM members WHERE room=? AND uid=?').bind(room, u.id).first();
    return { read: !!m || r.privacy === 'open' || isMod(u), write: !!m };
  }
  return { read: false, write: false };
}

async function strike(db, u, kind) {
  let s = (now() - (u.last_strike || 0) > 7 * DAY) ? 1 : (u.strikes || 0) + 1;
  let mute = 0, ban = 0;
  if (s >= 7) ban = 1; else if (s >= 5) mute = now() + DAY; else if (s >= 3) mute = now() + 3600000;
  await db.prepare('UPDATE users SET strikes=?, last_strike=?, muted_until=MAX(muted_until, ?), banned=MAX(banned, ?) WHERE id=?').bind(s, now(), mute, ban, u.id).run();
  if (mute || ban) await db.prepare('INSERT INTO modlog(ts,actor,action,target,info) VALUES(?,?,?,?,?)').bind(now(), 0, ban ? 'autoban' : 'automute', u.id, kind).run();
  return { strikes: s, mute, ban: !!ban };
}

/* ================= МАРШРУТЫ ================= */
async function social(req, url, env) {
  const db = env.DB;
  const p = url.pathname.replace(/\/+$/, '');
  const m = req.method.toUpperCase();
  const ip = req.headers.get('cf-connecting-ip') || '?';
  if (p === '/api/s/ping') return sj({ ok: true, db: !!db, app: /^[0-9a-f]{32}$/.test(SOC_APP) });
  if (!db) return err('no_db', 503);
  if (!hit('ip|' + ip, 240, 60000)) return err('busy', 429);
  await schema(db);
  // защита от подделки запросов: POST только со своего сайта и с заголовком X-WB
  if (m === 'POST') {
    const o = req.headers.get('origin'); if (o && new URL(o).host !== url.host) return err('origin', 403);
    if (req.headers.get('x-wb') !== '1') return err('csrf', 403);
  } else if (m !== 'GET') return err('method', 405);
  const body = m === 'POST' ? await req.json().catch(() => ({})) : {};
  const Q = k => url.searchParams.get(k);

  /* --- вход через Wargaming --- */
  if (p === '/api/s/login') {
    const realm = TLD[Q('realm')] ? Q('realm') : 'eu';
    const cb = `${url.origin}/api/s/cb?realm=${realm}`;
    const u = `https://api.worldoftanks.${TLD[realm]}/wot/auth/login/?application_id=${SOC_APP}&display=page&redirect_uri=${encodeURIComponent(cb)}`;
    return Response.redirect(u, 302);
  }
  if (p === '/api/s/cb') {
    const realm = TLD[Q('realm')] ? Q('realm') : 'eu';
    const back = (code) => Response.redirect(`${url.origin}/?chat=1${code ? '&chaterr=' + code : ''}`, 302);
    if (Q('status') !== 'ok' || !/^\d{1,12}$/.test(Q('account_id') || '') || !Q('access_token')) return back('cancel');
    if (!hit('login|' + ip, 20, 3600000)) return back('busy');
    let pr; try { pr = await wgPost(realm, 'auth/prolongate', { access_token: Q('access_token') }); } catch (e) { return back('wg'); }
    if (!pr || pr.status !== 'ok' || String(pr.data && pr.data.account_id) !== Q('account_id')) return back('verify');
    const id = +Q('account_id');
    let nick = clean(Q('nickname'), 24), clan_id = 0, clan_tag = '';
    try { const a = await wgb(realm, 'account/info', { account_id: id, fields: 'nickname' }); const d = a && a.data && a.data[id]; if (d && d.nickname) nick = d.nickname; else return back('noblitz'); } catch (e) {}
    try { const c = await wgb(realm, 'clans/accountinfo', { account_id: id, extra: 'clan', fields: 'clan_id,clan.tag' }); const d = c && c.data && c.data[id]; if (d && d.clan_id) { clan_id = d.clan_id; clan_tag = (d.clan && d.clan.tag) || ''; } } catch (e) {}
    const owner = nick.toLowerCase() === OWNER_NICK && realm === 'eu';
    const ex = await db.prepare('SELECT id, role FROM users WHERE id=?').bind(id).first();
    if (ex) await db.prepare('UPDATE users SET nick=?, nick_l=?, realm=?, clan_id=?, clan_tag=?, last_seen=?, role=CASE WHEN ? THEN \'owner\' ELSE role END WHERE id=?').bind(nick, nick.toLowerCase(), realm, clan_id, clan_tag, now(), owner ? 1 : 0, id).run();
    else await db.prepare('INSERT INTO users(id,realm,nick,nick_l,clan_id,clan_tag,avatar,role,created,last_seen) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(id, realm, nick, nick.toLowerCase(), clan_id, clan_tag, 'a1-' + (id % 5) + '-' + (id % 12) + '-' + (id % 24) + '-0-0', owner ? 'owner' : 'user', now(), now()).run();
    const tok = rnd(32);
    await db.prepare('INSERT INTO sessions(h,uid,created,expires,wgt,realm) VALUES(?,?,?,?,?,?)').bind(await sha(tok), id, now(), now() + 30 * DAY, (pr.data && pr.data.access_token) || '', realm).run();
    await db.prepare('DELETE FROM sessions WHERE expires<?').bind(now()).run();
    return new Response(null, { status: 302, headers: { Location: `${url.origin}/?chat=1`, 'Set-Cookie': `wbs=${tok}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${30 * 86400}`, 'Cache-Control': 'no-store' } });
  }

  const U = await me(req, db);
  if (p === '/api/s/me') return sj({ user: pubUser(U), owner: OWNER_NICK });
  if (p === '/api/s/logout' && m === 'POST') {
    if (U) { const s = await db.prepare('SELECT wgt, realm FROM sessions WHERE h=?').bind(U._h).first(); await db.prepare('DELETE FROM sessions WHERE h=?').bind(U._h).run(); try { if (s && s.wgt) await wgPost(s.realm || 'eu', 'auth/logout', { access_token: s.wgt }); } catch (e) {} }
    return sj({ ok: true }, 200, { 'Set-Cookie': 'wbs=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0' });
  }

  /* --- комнаты --- */
  if (p === '/api/s/rooms') {
    const out = { pub: PUB_ROOMS.map(([id, name]) => ({ id, name })), clan: null, groups: [], open: [], dms: [] };
    if (U && U.clan_id) out.clan = { id: 'clan:' + U.clan_id, name: (U.clan_tag ? '[' + U.clan_tag + ']' : 'Мой клан') };
    if (U) {
      const g = await db.prepare(`SELECT r.id, r.name, r.privacy, r.invite, r.owner, r.last_ts, m.last_read FROM members m JOIN rooms r ON r.id=m.room WHERE m.uid=? AND r.kind='group' ORDER BY r.last_ts DESC LIMIT 50`).bind(U.id).all();
      out.groups = g.results.map(r => ({ id: r.id, name: r.name, privacy: r.privacy, invite: r.owner === U.id ? r.invite : '', own: r.owner === U.id, unread: r.last_ts > (r.last_read || 0) }));
      const d = await db.prepare(`SELECT r.id, r.last_ts, m.last_read, u.id oid, u.nick, u.clan_tag, u.avatar, u.role, u.last_seen,
        (SELECT x.text FROM msgs x WHERE x.room=r.id AND x.hidden=0 ORDER BY x.id DESC LIMIT 1) lt,
        (SELECT x.card FROM msgs x WHERE x.room=r.id AND x.hidden=0 ORDER BY x.id DESC LIMIT 1) lc,
        (SELECT x.uid FROM msgs x WHERE x.room=r.id AND x.hidden=0 ORDER BY x.id DESC LIMIT 1) lu
        FROM members m JOIN rooms r ON r.id=m.room JOIN members o ON o.room=r.id AND o.uid!=m.uid LEFT JOIN users u ON u.id=o.uid
        WHERE m.uid=? AND r.kind='dm' ORDER BY r.last_ts DESC LIMIT 60`).bind(U.id).all();
      out.dms = d.results.map(r => ({ id: r.id, user: r.oid ? { id: r.oid, nick: r.nick, clan: r.clan_tag, av: r.avatar, role: r.role, seen: r.last_seen } : null, last: r.lu != null ? { t: String(r.lt || '').slice(0, 80), card: !!r.lc, mine: r.lu === U.id, ts: r.last_ts } : null, unread: r.last_ts > (r.last_read || 0) }));
    }
    const op = await db.prepare(`SELECT id, name FROM rooms WHERE kind='group' AND privacy='open' ORDER BY last_ts DESC LIMIT 20`).all();
    out.open = op.results;
    return sj(out);
  }
  if (p === '/api/s/msgs') {
    const room = clean(Q('room'), 60);
    const a = await access(db, U, room); if (!a.read) return err('no_access', 403);
    const after = +Q('after') || 0, before = +Q('before') || 0;
    let rs;
    const SEL = `SELECT m.id, m.uid, m.ts, m.text, m.card, m.hidden, u.nick, u.clan_tag, u.avatar, u.role FROM msgs m LEFT JOIN users u ON u.id=m.uid WHERE m.room=?`;
    if (after) rs = await db.prepare(SEL + ' AND m.id>? ORDER BY m.id ASC LIMIT 60').bind(room, after).all();
    else if (before) rs = await db.prepare(SEL + ' AND m.id<? ORDER BY m.id DESC LIMIT 40').bind(room, before).all();
    else rs = await db.prepare(SEL + ' ORDER BY m.id DESC LIMIT 40').bind(room).all();
    let list = rs.results; if (!after) list.reverse();
    const mod = isMod(U);
    let blocked = new Set();
    if (U) { const b = await db.prepare('SELECT bid FROM blocks WHERE uid=?').bind(U.id).all(); blocked = new Set(b.results.map(x => x.bid)); }
    list = list.filter(x => !blocked.has(x.uid)).map(x => ({ id: x.id, uid: x.uid, ts: x.ts, t: x.hidden && !mod ? '' : x.text, card: x.hidden && !mod ? '' : x.card, hid: x.hidden ? 1 : 0, nick: x.nick, clan: x.clan_tag || '', av: x.avatar || '', role: x.role || 'user' }));
    if (U && list.length) await db.prepare('INSERT INTO members(room,uid,last_read) VALUES(?,?,?) ON CONFLICT(room,uid) DO UPDATE SET last_read=excluded.last_read').bind(room, U.id, now()).run().catch(() => {});
    return sj({ room, msgs: list, write: a.write });
  }
  if (p === '/api/s/unread') {
    if (!U) return sj({ n: 0 });
    const r = await db.prepare(`SELECT COUNT(*) n FROM members m JOIN rooms r ON r.id=m.room WHERE m.uid=? AND r.kind IN ('dm','group') AND r.last_ts>m.last_read`).bind(U.id).first();
    return sj({ n: r ? r.n : 0 });
  }
  if (p === '/api/s/users') {
    const q = clean(Q('q'), 24).toLowerCase(); if (q.length < 2) return sj({ users: [] });
    const r = await db.prepare(`SELECT id,nick,clan_tag,avatar,role FROM users WHERE nick_l LIKE ? ESCAPE '\\' AND banned=0 ORDER BY last_seen DESC LIMIT 20`).bind(q.replace(/[\\%_]/g, '\\$&') + '%').all();
    return sj({ users: r.results.map(x => ({ id: x.id, nick: x.nick, clan: x.clan_tag, av: x.avatar, role: x.role })) });
  }
  if (p === '/api/s/user') {
    let u = null;
    if (Q('id')) u = await db.prepare('SELECT * FROM users WHERE id=?').bind(+Q('id') || 0).first();
    else if (Q('nick')) u = await db.prepare('SELECT * FROM users WHERE nick_l=?' + (Q('realm') ? ' AND realm=?' : '')).bind(...[clean(Q('nick'), 24).toLowerCase()].concat(Q('realm') ? [Q('realm')] : [])).first();
    if (!u) return sj({ user: null });
    const pu = pubUser(u); if (!isMod(U)) { delete pu.muted; }
    return sj({ user: pu });
  }

  /* --- дальше только для вошедших --- */
  if (!U) return err('login', 401);
  if (U.banned && p !== '/api/s/profile') return err('banned', 403);

  if (p === '/api/s/send' && m === 'POST') {
    const room = clean(body.room, 60);
    const a = await access(db, U, room); if (!a.write) return err('no_access', 403);
    if (U.muted_until > now()) return err('muted', 403, { until: U.muted_until });
    const text = clean(body.text, 600);
    let card = '';
    if (body.card) { try { const c = body.card; if (typeof c.t !== 'string' || c.t.length > 40) throw 0; card = JSON.stringify({ t: c.t, e: (c.e || []).slice(0, 9).map(x => +x | 0), c: (c.c || []).slice(0, 4).map(x => clean(x, 24)), p: (c.p || []).slice(0, 4).map(x => clean(x, 24)), k: (c.k || []).slice(0, 5).map(x => +x | 0), g: +c.g | 0 }); if (card.length > 900) throw 0; } catch (e) { return err('bad_card'); } }
    if (!text && !card) return err('empty');
    if (!hit('msg|' + U.id, 12, 30000)) { await db.prepare('UPDATE users SET muted_until=? WHERE id=?').bind(now() + 300000, U.id).run(); return err('flood', 429, { until: now() + 300000 }); }
    const slow = PUB_SET.has(room) ? 3000 : 700;
    const last = await db.prepare('SELECT ts, text FROM msgs WHERE uid=? ORDER BY id DESC LIMIT 1').bind(U.id).first();
    if (last && now() - last.ts < slow) return err('slow', 429, { wait: slow - (now() - last.ts) });
    if (last && text && last.text === text && now() - last.ts < 60000) return err('repeat');
    const f = filterText(text, url.host);
    if (f) { const s = f[0] === 'link' ? null : await strike(db, U, f[0]); return err('filtered', 422, { kind: f[0], reason: f[1], strikes: s ? s.strikes : 0, mute: s ? s.mute : 0, ban: s ? s.ban : false }); }
    if (room.startsWith('dm:')) {
      const [, x, y] = room.split(':'); const other = +(String(U.id) === x ? y : x);
      const bl = await db.prepare('SELECT 1 FROM blocks WHERE uid=? AND bid=?').bind(other, U.id).first(); if (bl) return err('blocked', 403);
    }
    const ts = now();
    const r = await db.prepare('INSERT INTO msgs(room,uid,ts,text,card) VALUES(?,?,?,?,?)').bind(room, U.id, ts, text, card).run();
    await db.prepare('UPDATE rooms SET last_ts=? WHERE id=?').bind(ts, room).run();
    await db.prepare('INSERT INTO members(room,uid,last_read) VALUES(?,?,?) ON CONFLICT(room,uid) DO UPDATE SET last_read=excluded.last_read').bind(room, U.id, ts).run();
    return sj({ ok: true, id: r.meta && r.meta.last_row_id, ts });
  }
  if (p === '/api/s/dm' && m === 'POST') {
    const to = +body.to | 0; if (!to || to === U.id) return err('bad_user');
    const o = await db.prepare('SELECT id, clan_id, dm_mode, banned FROM users WHERE id=?').bind(to).first(); if (!o || o.banned) return err('no_user', 404);
    const bl = await db.prepare('SELECT 1 FROM blocks WHERE uid=? AND bid=?').bind(to, U.id).first(); if (bl) return err('blocked', 403);
    const id = 'dm:' + Math.min(U.id, to) + ':' + Math.max(U.id, to);
    const ex = await db.prepare('SELECT id FROM rooms WHERE id=?').bind(id).first();
    if (!ex) {
      if (o.dm_mode === 'clan' && !(o.clan_id && o.clan_id === U.clan_id) && !isMod(U)) return err('dm_closed', 403);
      if (!hit('dmnew|' + U.id, 15, 3600000)) return err('busy', 429);
      await db.batch([db.prepare('INSERT INTO rooms(id,kind,name,created,last_ts) VALUES(?,?,?,?,?)').bind(id, 'dm', '', now(), 0), db.prepare('INSERT OR IGNORE INTO members(room,uid) VALUES(?,?)').bind(id, U.id), db.prepare('INSERT OR IGNORE INTO members(room,uid) VALUES(?,?)').bind(id, to)]);
    }
    return sj({ room: id });
  }
  if (p === '/api/s/group' && m === 'POST') {
    const name = clean(body.name, 40); const privacy = body.privacy === 'open' ? 'open' : 'link';
    if (name.length < 3) return err('short');
    const f = filterText(name, url.host); if (f) return err('filtered', 422, { reason: f[1] });
    const c = await db.prepare(`SELECT COUNT(*) n FROM rooms WHERE owner=? AND kind='group'`).bind(U.id).first(); if (c && c.n >= 5 && !isMod(U)) return err('limit');
    const id = 'g:' + rnd(6), inv = rnd(6);
    await db.batch([db.prepare('INSERT INTO rooms(id,kind,name,owner,privacy,invite,created,last_ts) VALUES(?,?,?,?,?,?,?,?)').bind(id, 'group', name, U.id, privacy, inv, now(), now()), db.prepare('INSERT INTO members(room,uid,role,last_read) VALUES(?,?,?,?)').bind(id, U.id, 'owner', now())]);
    return sj({ room: id, invite: inv });
  }
  if (p === '/api/s/join' && m === 'POST') {
    let r = null;
    if (body.invite) r = await db.prepare(`SELECT id FROM rooms WHERE invite=? AND kind='group'`).bind(clean(body.invite, 20)).first();
    else if (body.room) r = await db.prepare(`SELECT id FROM rooms WHERE id=? AND kind='group' AND privacy='open'`).bind(clean(body.room, 40)).first();
    if (!r) return err('not_found', 404);
    await db.prepare('INSERT OR IGNORE INTO members(room,uid,last_read) VALUES(?,?,?)').bind(r.id, U.id, 0).run();
    return sj({ room: r.id });
  }
  if (p === '/api/s/leave' && m === 'POST') {
    await db.prepare('DELETE FROM members WHERE room=? AND uid=?').bind(clean(body.room, 60), U.id).run(); return sj({ ok: true });
  }
  if (p === '/api/s/profile' && m === 'POST') {
    const av = AV_RX.test(String(body.av || '')) ? body.av : null;
    const st = body.st != null ? clean(body.st, 80) : null;
    if (st) { const f = filterText(st, url.host); if (f) return err('filtered', 422, { reason: f[1] }); }
    const dm = body.dm === 'clan' ? 'clan' : body.dm === 'all' ? 'all' : null;
    await db.prepare('UPDATE users SET avatar=COALESCE(?,avatar), status=COALESCE(?,status), dm_mode=COALESCE(?,dm_mode) WHERE id=?').bind(av, st, dm, U.id).run();
    return sj({ ok: true });
  }
  if (p === '/api/s/report' && m === 'POST') {
    const mid = +body.mid | 0; const x = await db.prepare('SELECT id, uid FROM msgs WHERE id=?').bind(mid).first(); if (!x) return err('not_found', 404);
    if (x.uid === U.id) return err('self');
    const r = await db.prepare('INSERT OR IGNORE INTO reports(mid,uid,ts) VALUES(?,?,?)').bind(mid, U.id, now()).run();
    if (r.meta && r.meta.changes) {
      const c = await db.prepare('SELECT COUNT(*) n FROM reports WHERE mid=?').bind(mid).first();
      await db.prepare('UPDATE msgs SET reports=? WHERE id=?').bind(c.n, mid).run();
      if (c.n >= 3) { await db.prepare('UPDATE msgs SET hidden=1 WHERE id=?').bind(mid).run(); const au = await db.prepare('SELECT * FROM users WHERE id=?').bind(x.uid).first(); if (au && au.role === 'user') await strike(db, au, 'reports'); await db.prepare('INSERT INTO modlog(ts,actor,action,target,info) VALUES(?,?,?,?,?)').bind(now(), 0, 'autohide', x.uid, 'msg ' + mid).run(); }
    }
    return sj({ ok: true });
  }
  if (p === '/api/s/block' && m === 'POST') {
    const b = +body.uid | 0; if (!b || b === U.id) return err('bad_user');
    if (body.on) await db.prepare('INSERT OR IGNORE INTO blocks(uid,bid) VALUES(?,?)').bind(U.id, b).run();
    else await db.prepare('DELETE FROM blocks WHERE uid=? AND bid=?').bind(U.id, b).run();
    return sj({ ok: true });
  }

  /* --- модерация --- */
  if (p === '/api/s/mod' && m === 'POST') {
    if (!isMod(U)) return err('forbidden', 403);
    const act = String(body.action || '');
    let target = +body.uid | 0;
    if (body.mid) { const x = await db.prepare('SELECT uid FROM msgs WHERE id=?').bind(+body.mid | 0).first(); if (!x) return err('not_found', 404); target = target || x.uid; }
    const T = target ? await db.prepare('SELECT * FROM users WHERE id=?').bind(target).first() : null;
    if (T && T.role === 'owner' && U.role !== 'owner') return err('forbidden', 403);
    if (T && T.role === 'mod' && U.role !== 'owner' && act !== 'hide') return err('forbidden', 403);
    const log = info => db.prepare('INSERT INTO modlog(ts,actor,action,target,info) VALUES(?,?,?,?,?)').bind(now(), U.id, act, target, info || '').run();
    if (act === 'hide' || act === 'unhide') { await db.prepare('UPDATE msgs SET hidden=? WHERE id=?').bind(act === 'hide' ? 1 : 0, +body.mid | 0).run(); await log('msg ' + body.mid); return sj({ ok: true }); }
    if (!T) return err('no_user', 404);
    if (T.id === U.id) return err('self');
    if (act === 'mute') { const min = Math.max(5, Math.min(60 * 24 * 30, +body.minutes || 60)); await db.prepare('UPDATE users SET muted_until=? WHERE id=?').bind(now() + min * 60000, T.id).run(); await log(min + ' min'); return sj({ ok: true }); }
    if (act === 'unmute') { await db.prepare('UPDATE users SET muted_until=0, strikes=0 WHERE id=?').bind(T.id).run(); await log(); return sj({ ok: true }); }
    if (act === 'ban') { await db.batch([db.prepare('UPDATE users SET banned=1 WHERE id=?').bind(T.id), db.prepare('DELETE FROM sessions WHERE uid=?').bind(T.id)]); await log(); return sj({ ok: true }); }
    if (act === 'unban') { await db.prepare('UPDATE users SET banned=0, strikes=0, muted_until=0 WHERE id=?').bind(T.id).run(); await log(); return sj({ ok: true }); }
    if (act === 'purge') { await db.prepare('UPDATE msgs SET hidden=1 WHERE uid=? AND ts>?').bind(T.id, now() - DAY).run(); await log('24h'); return sj({ ok: true }); }
    if ((act === 'setmod' || act === 'unmod') && U.role === 'owner') { await db.prepare('UPDATE users SET role=? WHERE id=? AND role!=\'owner\'').bind(act === 'setmod' ? 'mod' : 'user', T.id).run(); await log(); return sj({ ok: true }); }
    return err('bad_action');
  }
  if (p === '/api/s/modlog') {
    if (!isMod(U)) return err('forbidden', 403);
    const r = await db.prepare('SELECT l.*, a.nick an, t.nick tn FROM modlog l LEFT JOIN users a ON a.id=l.actor LEFT JOIN users t ON t.id=l.target ORDER BY l.id DESC LIMIT 100').all();
    const rep = await db.prepare('SELECT m.id, m.text, m.uid, m.reports, m.hidden, u.nick FROM msgs m LEFT JOIN users u ON u.id=m.uid WHERE m.reports>0 ORDER BY m.id DESC LIMIT 50').all();
    return sj({ log: r.results, reported: rep.results });
  }
  return err('not_found', 404);
}

/* ---------- маршрутизация ---------- */
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const p = url.pathname;
    try {
      if (p === '/api/yt' || p === '/api/yt/') return await yt(request, url);
      if (p === '/api/geo' || p === '/api/geo/') return geo(request, url);
      if (p === '/api/news' || p === '/api/news/') return await news(request, url);
      if (p.startsWith('/api/s/')) return await social(request, url, env);
      if (p.startsWith('/api/')) return out('not found', 404);
    } catch (e) { return out('', 500); }
    const r = await env.ASSETS.fetch(request);
    const res = new Response(r.body, r);
    for (const [rx, hs] of HDR_RX) if (rx.test(p)) for (const h of hs) res.headers.set(h.key, h.value);
    return res;
  }
};
