// «Мой ангар» — сервис-воркер: сайт открывается как приложение и запускается даже без интернета
// (последняя загруженная версия). Всегда сначала пробует свежую версию из сети.
const CACHE = 'wb-app-v13';
const SHELL = ['/', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png', '/icon-maskable-512.png', '/icon-180.png'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {}));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/')) return; // чужие сайты и API — напрямую
  if (r.mode === 'navigate') {   // страница: сеть → если нет связи, сохранённая копия
    e.respondWith(fetch(r).then(res => { const cp = res.clone(); caches.open(CACHE).then(c => c.put('/', cp)); return res; })
      .catch(() => caches.match('/').then(m => m || caches.match(r))));
    return;
  }
  if (u.pathname.startsWith('/fonts/') || u.pathname.startsWith('/maps/') || u.pathname.startsWith('/vendor/') || u.pathname.startsWith('/art/')) {   // шрифты, миникарты и картинки тем не меняются — из кэша, а если нет — скачать и запомнить
    e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => { if (res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put(r, cp)); } return res; })));
    return;
  }
  if (SHELL.includes(u.pathname)) e.respondWith(caches.match(r).then(m => m || fetch(r)));
});
